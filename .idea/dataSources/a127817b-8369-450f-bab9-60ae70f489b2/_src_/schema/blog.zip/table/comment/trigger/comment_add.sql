CREATE TRIGGER comment_add
BEFORE INSERT ON comment
FOR EACH ROW
  BEGIN
    SET NEW.user_nickname = (
      SELECT nickname FROM user WHERE id = NEW.user_id
    );
  END;
