CREATE TRIGGER before_article_add
BEFORE INSERT ON article
FOR EACH ROW
  BEGIN
    SET NEW.author_nickname = (
      SELECT nickname FROM user WHERE id = NEW.author_id
    );
  END;
