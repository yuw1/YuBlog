CREATE PROCEDURE user_auth(IN id INT, IN nickname VARCHAR(20), IN password VARCHAR(30), OUT token INT)
  BEGIN

#     DECLARE nickname VARCHAR(20);
    DECLARE password_sha1_nickname VARCHAR(60);
    DECLARE password_sha1_nickname1 VARCHAR(60);
    DECLARE user_count INT;
    SELECT count(*) FROM user WHERE id = id INTO user_count;
    IF user_count = 0
    THEN
      SET token = 0;
    ELSE
#       SELECT nickname INTO nickname FROM user WHERE id = 10001 LIMIT 1;

      SET password_sha1_nickname = concat(sha1(password),nickname);

      SELECT password_sha1_nickname FROM user WHERE id = id LIMIT 1 INTO password_sha1_nickname1;
      IF password_sha1_nickname = password_sha1_nickname1
      THEN 
        SET token = 1;
      ELSE
        SET token = 2;
      END IF;
    END IF;

  END;
