CREATE PROCEDURE user_update(IN `_id` INT, IN `_nickname` VARCHAR(20), IN `_password` VARCHAR(30))
  BEGIN
    declare _password_sha1_nickname varchar(60);
    set _password_sha1_nickname = concat(sha1(_password),_nickname);
    UPDATE user SET nickname = _nickname, password_sha1_nickname = _password_sha1_nickname WHERE id = _id;
  END;
