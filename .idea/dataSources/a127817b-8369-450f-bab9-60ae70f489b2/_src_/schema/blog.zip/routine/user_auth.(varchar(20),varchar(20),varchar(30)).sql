CREATE PROCEDURE user_auth(IN id VARCHAR(20), IN nickname VARCHAR(20), IN password VARCHAR(30), OUT token INT)
  BEGIN
    declare password_sha1_nickname varchar(52);
    set password_sha1_nickname = concat(sha1(password),nickname);

    IF (SELECT count(*) FROM user WHERE id = id) = 0 
    THEN
      SET token = 0;
    ELSE
      IF (SELECT password_sha1_nickname FROM user WHERE id = id) != password_sha1_nickname 
      THEN 
        SET token = 1;
      ELSE
        SET token = 2;
      END IF;
    END IF;

  END;
