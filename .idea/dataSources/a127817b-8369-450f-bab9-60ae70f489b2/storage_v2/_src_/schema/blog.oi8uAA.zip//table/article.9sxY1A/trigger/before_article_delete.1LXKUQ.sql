CREATE TRIGGER before_article_delete
  BEFORE DELETE
  ON article
  FOR EACH ROW
  BEGIN
    DELETE FROM comment WHERE comment.article_id = OLD.id;
  END;

