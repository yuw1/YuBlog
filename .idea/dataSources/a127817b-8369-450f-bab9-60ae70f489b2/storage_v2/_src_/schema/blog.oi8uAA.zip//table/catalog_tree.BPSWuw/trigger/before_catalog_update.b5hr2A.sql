CREATE TRIGGER before_catalog_update
  BEFORE UPDATE
  ON catalog_tree
  FOR EACH ROW
  BEGIN

    UPDATE article SET article.catalog_name = NEW.name WHERE article.catalog_id = NEW.id;

  END;

