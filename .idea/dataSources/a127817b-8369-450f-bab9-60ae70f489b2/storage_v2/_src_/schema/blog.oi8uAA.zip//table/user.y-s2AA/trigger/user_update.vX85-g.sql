CREATE TRIGGER user_update
  BEFORE UPDATE
  ON user
  FOR EACH ROW
  BEGIN
    UPDATE comment SET comment.user_pic = NEW.user_pic WHERE comment.user_id = NEW.id;
  END;

