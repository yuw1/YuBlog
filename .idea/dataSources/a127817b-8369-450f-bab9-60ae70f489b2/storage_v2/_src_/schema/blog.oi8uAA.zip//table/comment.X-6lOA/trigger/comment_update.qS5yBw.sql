CREATE TRIGGER comment_update
  BEFORE UPDATE
  ON comment
  FOR EACH ROW
  BEGIN

    SET NEW.last_modified = now();

  END;

