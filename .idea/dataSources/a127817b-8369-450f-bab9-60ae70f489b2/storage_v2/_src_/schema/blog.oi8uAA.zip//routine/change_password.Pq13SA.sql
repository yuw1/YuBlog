CREATE PROCEDURE change_password(IN `_id` INT, IN `_password` VARCHAR(30))
  BEGIN
    declare _password_md5_id varchar(52);
    set _password_md5_id = MD5(concat(concat(concat(_password,'{'),`_id`),'}'));
    UPDATE user SET password_md5 = _password_md5_id WHERE id=`_id`;
  END;

